describe('City Map Application', () => {
  beforeEach(() => {
    cy.visit('http://127.0.0.1:5500/client/pages/index.html'); // Assurez-vous que c'est la bonne URL.
  });

  it('Affiche toutes les villes au chargement de la page', () => {
    cy.intercept('GET', 'http://localhost:8080/cities', { fixture: 'cities.json' }).as('getCities');
    cy.wait('@getCities');
    cy.get('#citiesList').children().should('have.length', 2018); // Assurez-vous que le nombre correspond au nombre de villes dans votre fixture 'cities.json'.
  });



  it('Recherche et trouve une ville', () => {
    // Effacer le contenu du champ de recherche
    cy.get('#search-input').clear();

    // Assurez-vous d'abord que l'interception est correctement mise en place.
    cy.intercept('GET', 'http://localhost:8080/cities').as('getSuggestions');

    // Ensuite, tapez dans le champ de recherche pour déclencher la requête
    cy.get('#search-input').type('Par');

    // Attendre un court délai avant de vérifier si la suggestion est affichée (par exemple 1000 ms)
    cy.wait(1000);

    // Vérifiez que la suggestion "Paris" est présente
    cy.get('#suggestions-list').should('contain', 'Paris');
  });

  it('Affiche toutes les villes d\'une région lorsqu\'on clique dessus', () => {
    // Intercepter l'appel API qui récupère les villes d'une région spécifique
    cy.intercept('GET', 'http://localhost:8080/cities?region=Ile-de-France').as('getCitiesByRegion');

    // Simuler un clic sur la région 'Ile-de-France' en utilisant l'ID de l'élément path
    cy.get('path#FRIDF').click();

    // Attendre que la réponse de l'appel API soit reçue
    cy.wait('@getCitiesByRegion');

    // Vérifier que la liste des villes pour cette région est affichée
    cy.get('#citiesList').should('be.visible');

    // Vérifier que le titre de la liste contient 'Ile-de-France'
    cy.get('#results-heading').should('contain', 'Ile-de-France');

    // Et que chaque élément de la liste est bien une ville de la région sélectionnée
    // (Cette partie du test pourrait nécessiter un accès à la structure de données pour être précise.)
  });




});